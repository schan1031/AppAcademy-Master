export const signup = () => (
  $.ajax({ method: 'GET', url: '/api/pokemon' })
);
